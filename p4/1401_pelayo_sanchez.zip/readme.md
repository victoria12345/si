Autores:  Victoria Pelayo y Sofía Sánchez.

La aplicación está dentro de la carpeta SI1-Practicas.

Hemos añadido también el fichero dump(es el proporcionado en moodle) para la base de datos.

